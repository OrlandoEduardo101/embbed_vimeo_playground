import 'package:remedi_localization/country_selection_theme.dart';
import 'package:remedi_localization/selection_list.dart';
import 'package:remedi_localization/support/code_countries_en.dart';
import 'package:remedi_localization/support/code_country.dart';
import 'package:remedi_localization/support/code_countrys.dart';
import 'package:flutter/material.dart';

import 'support/code_country.dart';

class CountryListPick extends StatefulWidget {
  CountryListPick({
    Key? key,
    this.enabled = true,
    this.onChanged,
    this.initialSelection,
    this.appBar,
    this.pickerBuilder,
    this.countryBuilder,
    this.theme,
    this.useUiOverlay = true,
    this.useSafeArea = false,
    this.backgroundColor,
  }) : super(key: key);
  final bool enabled;
  final String? initialSelection;
  final ValueChanged<CountryCode?>? onChanged;
  final PreferredSizeWidget? appBar;
  final Widget Function(BuildContext context, CountryCode? countryCode)?
  pickerBuilder;
  final CountryTheme? theme;
  final Widget Function(BuildContext context, CountryCode countryCode)?
  countryBuilder;
  final bool useUiOverlay;
  final bool useSafeArea;
  final Color? backgroundColor;

  @override
  CountryListPickState createState() {
    List<Map> jsonList =
    this.theme?.showEnglishName ?? true ? countriesEnglish : codes;

    List elements = jsonList
        .map((s) => CountryCode(
      name: s['name'],
      code: s['code'],
      dialCode: s['dial_code'],
      flagUri: 'assets/flags/${s['code'].toLowerCase()}.png',
    ))
        .toList();
    return CountryListPickState(elements);
  }
}

class CountryListPickState extends State<CountryListPick> {
  CountryCode? selectedItem;
  List elements = [];

  CountryListPickState(this.elements);

  @override
  void initState() {
    if (widget.initialSelection != null) {
      selectedItem = elements.firstWhere(
              (e) =>
          (e.code.toUpperCase() ==
              widget.initialSelection!.toUpperCase()) ||
              (e.dialCode == widget.initialSelection),
          orElse: () => elements[0] as CountryCode);
    } else {
      selectedItem = elements[0];
    }

    super.initState();
  }

  void awaitFromSelectScreen(BuildContext context, PreferredSizeWidget? appBar,
      CountryTheme? theme) async {
    final result = await Navigator.push(
        context,
        MaterialPageRoute(
          builder: (context) => SelectionList(
            elements,
            selectedItem,
            appBar: widget.appBar ??
                AppBar(
                  backgroundColor: Theme.of(context).appBarTheme.color,
                  title: Text("Select Country"),
                ),
            theme: theme,
            countryBuilder: widget.countryBuilder,
            useUiOverlay: widget.useUiOverlay,
            useSafeArea: widget.useSafeArea,
            backgroundColor: widget.backgroundColor,
          ),
        ));

    setState(() {
      selectedItem = result ?? selectedItem;
      widget.onChanged!(result ?? selectedItem);
    });
  }

  @override
  Widget build(BuildContext context) {
    return TextButton(
      onPressed: () {
        if (widget.enabled) {
          awaitFromSelectScreen(context, widget.appBar, widget.theme);
        }
      },
      child: widget.pickerBuilder != null
          ? widget.pickerBuilder!(context, selectedItem)
          : Flex(
        direction: Axis.horizontal,
        mainAxisSize: MainAxisSize.min,
        children: <Widget>[
          if (widget.theme?.isShowFlag ?? true == true)
            Flexible(
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 5.0),
                child: Image.asset(
                  selectedItem!.flagUri!,
                  package: 'remedi_localization',
                  width: 32.0,
                ),
              ),
            ),
          if (widget.theme?.isShowCode ?? true == true)
            Flexible(
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 5.0),
                child: Text(selectedItem.toString()),
              ),
            ),
          if (widget.theme?.isShowTitle ?? true == true)
            Flexible(
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 5.0),
                child: Text(selectedItem!.toCountryStringOnly()),
              ),
            ),
          if (widget.theme?.isDownIcon ?? true == true)
            Flexible(
              child: Icon(Icons.keyboard_arrow_down),
            )
        ],
      ),
    );
  }
}

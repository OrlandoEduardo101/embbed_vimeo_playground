#import <Flutter/Flutter.h>

@interface RemediLocalizationPlugin : NSObject<FlutterPlugin>
@end

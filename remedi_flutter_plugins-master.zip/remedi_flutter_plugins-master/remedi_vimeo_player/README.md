
# Introduce.
 ##### This plugin has two features

  1. Getting Vimeo Resource Data.
  2. Play Vimeo Vod and Live Streaming.


## 1. Getting Vimeo Resouce Data.

  a. Create a instance of Vimeo class, it keep vimeo video id and access key.
  
  b. If the vod or hls is public, do not need to pass access key.
  
  c. 'video' getter give .mp4 url or .hls url of the vimeo video
  
  d. Play the vod or live streaming using the url.
  


## 2. Play Vimeo Vod and Live Streaming


  We use better player to play vimeo.
  
  'VimeoVideo' class provide .mp4 and .m3u8 url.
  
  So you want to use other player, you can do.


## 0.2.1
* update plugins

## 0.1.6
* migrate better player version to 0.0.73#2

## 0.1.5
* migrate better player version to 0.0.73

## 0.1.4
* update better player version. to fix ios build error on swift 5.5

## 0.1.3
* disable web support

## 0.1.2
* add codes to handle some error cases.

## 0.1.1
* documentation formatting.

## 0.1.0
* add documentation.

## 0.0.3
* add homepage and repository

## 0.0.2
* Support live stream (private/public)

## 0.0.1
* Support vod (private/public)

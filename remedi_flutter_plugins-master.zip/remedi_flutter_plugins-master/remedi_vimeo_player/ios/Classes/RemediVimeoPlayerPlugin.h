#import <Flutter/Flutter.h>

@interface RemediVimeoPlayerPlugin : NSObject<FlutterPlugin>
@end

# multiscreen
This plug-in helps applications design differently from GUI guides,
 even on devices with different resolutions.
 
 Please refer example code.
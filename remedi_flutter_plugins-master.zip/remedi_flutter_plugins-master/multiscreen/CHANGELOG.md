## 3.0.1
support dart sdk from 2.12.0
## 3.0.0
- support android embed v2
## 2.0.0
- support null-safety
## 1.3.0
- add some options as dp size
- if guide size is null, return origin input.
## 1.2.1
remove debug print
## 1.2.0
support rotate screen
## 1.1.0
change how to use.
##1.0.6
remove Singleton.
##1.0.5
update gradle
##1.0.4
fix conflict
##1.0.3
update gradle and kotlin
##1.0.2
update gradle and kotlin
##1.0.1
add readme and example code.
## 1.0.0
Release First version.
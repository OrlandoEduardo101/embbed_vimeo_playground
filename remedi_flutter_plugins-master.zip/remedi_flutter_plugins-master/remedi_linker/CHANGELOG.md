## [0.0.2]

## [0.1.9]

* Corrected a error, text after every last link was not captured, FIXED

## [0.1.6]

* Commented on all LinkWell propeties and methods
* Added Readme.md
* Formatted Code
* Fixed Bug Issues


## [0.1.2]

* Commented on all LinkWell propeties and methods
* Added Readme.md
* Formatted Code
* Fixed Bug Issues


## [0.1.1+5]

* Created more properties in the LinkWell Class
* Added Example project

## [0.1.1+2]

* Error in LinkWell Class fixed

## [0.1.1+1]

* Made a few corrections, not critical, previous version does not show text when no link detected

## [0.1.1]

* Initial release,

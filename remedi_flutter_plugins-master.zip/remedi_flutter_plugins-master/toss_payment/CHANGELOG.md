## 0.2.6
 update plugins

## 0.2.5
 update license

## 0.2.4
 change env.

## 0.2.3
 Update Comments

## 0.2.2
 Update Comments and add '토스결제' case to example

## 0.2.1
 add Widget dispose and tap close callbacks

## 0.2.0
 add WebView callback to class PaymentWebView

## 0.1.2
 update change log

## 0.1.1
 change example app's package name

## 0.1.0
 update readme and refactor package

## 0.0.1
 initial release

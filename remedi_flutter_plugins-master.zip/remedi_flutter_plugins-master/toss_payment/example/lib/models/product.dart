class Product {
  final int price;
  final String name;

  Product({
    required this.price,
    required this.name,
  });
}

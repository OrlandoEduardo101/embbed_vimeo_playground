## [0.0.2] - Support for Null Safety

## [0.0.1] - First Release.
